Hello, this is the ADP code challenge source code and instructions how to run it:

Unzip the files into your local directory, with project level folder called EmpInfo

navigate to EmpInfo and execute the following commands

npm install
npm run serve

And to view the page, use this URL in the browser
http://localhost:2002


Thank you,
Ranjith